import unittest
from core.validator import is_valid_qris_string, calculate_crc16

class TestValidator(unittest.TestCase):
    def test_crc16_known_string(self):
        # Contoh string QRIS tanpa CRC
        qr_core = "00020101021126570011ID.DANA.WWW011893600915357570779002095757077900303UMI"
        expected_crc = "3F06"  # Misalnya diketahui sebelumnya (buat test mandiri)
        
        # CRC hasil hitung harus sesuai
        result_crc = calculate_crc16(qr_core)
        self.assertEqual(result_crc, expected_crc)

    def test_valid_qris_string(self):
        # Format QR lengkap termasuk CRC yang sesuai
        valid_qr = "0002010102115802ID5909Xie Store63043F06"
        self.assertTrue(is_valid_qris_string(valid_qr))

    def test_invalid_qris_string_missing_prefix(self):
        invalid_qr = "1111010102115802ID5909Xie Store63043F06"
        self.assertFalse(is_valid_qris_string(invalid_qr))

    def test_invalid_qris_string_missing_tag(self):
        invalid_qr = "0002010102115909Xie Store63043F06"
        self.assertFalse(is_valid_qris_string(invalid_qr)

    def test_invalid_qris_string_crc_mismatch(self):
        # CRC terakhir tidak sesuai dengan hasil perhitungan
        qr_wrong_crc = "0002010102115802ID5909Xie Store63040000"
        self.assertFalse(is_valid_qris_string(qr_wrong_crc))

if __name__ == '__main__':
    unittest.main()
