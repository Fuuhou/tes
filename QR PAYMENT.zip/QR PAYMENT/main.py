import sys
from core.generator import generate_qr
from core.validator import is_valid_qris_string
from core.checker import check_payment_status
from core.utils import format_rupiah, generate_tx_id

def main():
    try:
        # Ambil nominal dari argumen CLI atau input manual
        if len(sys.argv) > 1:
            try:
                amount = int(sys.argv[1])
            except ValueError:
                print("❌ Nominal harus berupa angka bulat.")
                return
        else:
            amount_str = input("Masukkan nominal pembayaran (contoh: 10000): ")
            try:
                amount = int(amount_str)
            except ValueError:
                print("❌ Input tidak valid, hanya boleh angka.")
                return

        tx_id = generate_tx_id()

        # 1. Generate QR
        qr_result = generate_qr(amount, save_as=f"qr_{amount}_{tx_id}.png")
        qr_string = qr_result['qr_string']
        qr_path = qr_result['qr_image_path']

        print(f"[INFO] QRIS {format_rupiah(amount)} berhasil dibuat:")
        print(f"  ⤷ Path gambar: {qr_path}")
        print(f"  ⤷ QR string: {qr_string}")
        print(f"  ⤷ ID Transaksi: {tx_id}")

        # 2. Validasi QR string
        if is_valid_qris_string(qr_string):
            print("[VALIDATOR] ✅ QR string lolos validasi format & CRC16")
        else:
            print("[VALIDATOR] ❌ QR string tidak valid!")

        # 3. Monitor status pembayaran
        print(f"[MONITOR] 🔄 Memantau status pembayaran {format_rupiah(amount)}...")
        status = check_payment_status(reference_id=tx_id, amount=amount)

        if status:
            print("[STATUS] 🎉 Pembayaran berhasil diterima!")
            print("  ⤷ Detail transaksi:")
            for k, v in status.items():
                print(f"    - {k}: {v}")
        else:
            print("[STATUS] ⚠️ Pembayaran tidak diterima (timeout atau gagal)")

    except Exception as e:
        print(f"[ERROR] 🚫 Terjadi kesalahan: {str(e)}")

if __name__ == "__main__":
    main()
