import unittest
import os
from core.generator import generate_qr
from config.settings import QR_SAVE_PATH

class TestQRGenerator(unittest.TestCase):
    def test_generate_valid_amount(self):
        amount = 10000
        result = generate_qr(amount, save_as='test_qr.png')
        self.assertIn('qr_string', result)
        self.assertIn('qr_image_path', result)
        self.assertTrue(os.path.exists(result['qr_image_path']))
    
    def test_generate_invalid_amount_zero(self):
        with self.assertRaises(ValueError):
            generate_qr(0)

    def test_generate_invalid_amount_negative(self):
        with self.assertRaises(ValueError):
            generate_qr(-5000)

    def tearDown(self):
        test_path = os.path.join(QR_SAVE_PATH, 'test_qr.png')
        if os.path.exists(test_path):
            os.remove(test_path)

if __name__ == '__main__':
    unittest.main()
