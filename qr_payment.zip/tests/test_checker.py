import unittest
from core.checker import check_payment_status

class TestPaymentChecker(unittest.TestCase):
    def test_valid_amount_monitoring(self):
        # Note: Akan melewati timeout jika tidak ada sistem aktif.
        amount = 10000
        result = check_payment_status(reference_id="TESTREF123", amount=amount)

        # Dalam sistem uji tanpa backend aktif, hasilnya mungkin None
        self.assertTrue(result is None or 'status' in result)

    def test_invalid_zero_amount(self):
        with self.assertRaises(ValueError):
            check_payment_status(reference_id="REFZERO", amount=0)

    def test_invalid_negative_amount(self):
        with self.assertRaises(ValueError):
            check_payment_status(reference_id="REFNEG", amount=-3000)

if __name__ == '__main__':
    unittest.main()
