import os
import uuid
import logging
from datetime import datetime
from config.settings import LOG_FILE_PATH, DEBUG_MODE

# ─────────────────────────────────────────────
# 📋 Logging Setup
# ─────────────────────────────────────────────
def setup_logger(name='qr_payment', log_file=LOG_FILE_PATH, level=logging.INFO):
    """
    Inisialisasi logger terstruktur.
    """
    formatter = logging.Formatter('[%(asctime)s] %(levelname)s — %(message)s')
    handler = logging.FileHandler(log_file)
    handler.setFormatter(formatter)

    logger = logging.getLogger(name)
    logger.setLevel(level)
    if not logger.hasHandlers():
        logger.addHandler(handler)

    return logger

# ─────────────────────────────────────────────
# 📁 Path Helper
# ─────────────────────────────────────────────
def ensure_directory_exists(path):
    """
    Membuat folder jika belum ada.
    """
    if not os.path.exists(path):
        os.makedirs(path)

def generate_tx_id():
    """
    Menghasilkan ID transaksi unik sepanjang 8 karakter.
    Contoh: 'a3f7c12b'
    """
    return str(uuid.uuid4())[:8]

# ─────────────────────────────────────────────
# 🧾 Formatter
# ─────────────────────────────────────────────
def format_rupiah(amount: int):
    """
    Format angka menjadi string Rupiah yang ramah pengguna.
    """
    return f"Rp {amount:,}".replace(",", ".")

def debug_print(msg: str):
    """
    Cetak debug ke konsol jika DEBUG_MODE aktif.
    """
    if DEBUG_MODE:
        print(f"[DEBUG] {msg}")
