import os
from PIL import Image
from qris_payment import QRISPayment
from config.env import load_credentials
from config.settings import DEBUG_MODE, DEFAULT_LOGO_PATH, QR_SAVE_PATH
from core.utils import generate_tx_id

def generate_qr(amount, logo_path=None, save_as=None):
    if amount <= 0:
        raise ValueError("Amount harus lebih besar dari 0")

    try:
        creds = load_credentials()

        config = {
            'auth_username': creds['auth_username'],
            'auth_token': creds['auth_token'],
            'base_qr_string': creds['base_qr_string'],
            'logo_path': logo_path or DEFAULT_LOGO_PATH
        }

        qris = QRISPayment(config)
        result = qris.generate_qr(amount)

        # Gunakan tx_id untuk nama file unik
        tx_id = generate_tx_id()
        filename = save_as or f"qr_{amount}_{tx_id}.png"
        filepath = os.path.join(QR_SAVE_PATH, filename)

        result['qr_image'].save(filepath)

        if DEBUG_MODE:
            print(f"[DEBUG] QR generated for Rp{amount} ({tx_id}) → {filepath}")

        return {
            'qr_string': result['qr_string'],
            'qr_image_path': filepath,
            'tx_id': tx_id
        }

    except Exception as e:
        if DEBUG_MODE:
            print(f"[ERROR] Gagal generate QR: {str(e)}")
        raise
