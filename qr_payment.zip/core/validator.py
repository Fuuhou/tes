def is_valid_qris_string(qr_string):
    """
    Validasi awal struktur QRIS string berdasarkan indikator dasar:
    - Harus dimulai dengan 000201
    - Harus mengandung tag 5802ID
    - Harus berakhiran CRC valid
    
    :param qr_string: str
    :return: bool
    """
    if not qr_string.startswith("000201"):
        return False
    if "5802ID" not in qr_string:
        return False
    if not qr_string.endswith(calculate_crc16(qr_string[:-4])):
        return False
    return True

def calculate_crc16(qr_core_string):
    """
    Hitung CRC16-CCITT (XModem) dari QR string QRIS (tanpa 4 digit CRC di akhir).
    
    :param qr_core_string: str
    :return: str, hasil CRC dalam format hex upper-case
    """
    crc = 0xFFFF
    polynomial = 0x1021

    bytes_data = bytearray(qr_core_string.encode('utf-8'))

    for b in bytes_data:
        crc ^= (b << 8)
        for _ in range(8):
            if (crc & 0x8000):
                crc = (crc << 1) ^ polynomial
            else:
                crc <<= 1
            crc &= 0xFFFF  # pastikan tetap 16-bit

    return format(crc, '04X')
