import time
from qris_payment.payment_checker import PaymentChecker
from config.env import load_credentials
from config.settings import DEBUG_MODE, CHECK_TIMEOUT, CHECK_INTERVAL

def check_payment_status(reference_id: str, amount: int):
    """
    Memantau status pembayaran QRIS untuk nominal tertentu dan reference ID unik.

    :param reference_id: str, ID transaksi (wajib untuk keunikan monitoring)
    :param amount: int, nominal transaksi
    :return: dict | None jika timeout / belum dibayar
    """
    if amount <= 0:
        raise ValueError("Amount harus lebih besar dari 0")

    try:
        creds = load_credentials()

        checker = PaymentChecker({
            'auth_username': creds['auth_username'],
            'auth_token': creds['auth_token']
        }, debug=DEBUG_MODE)

        start_time = time.time()
        while time.time() - start_time < CHECK_TIMEOUT:
            result = checker.check_payment_status(reference_id, amount)
            logger.info(f"[{reference_id}] Status transaksi Rp{amount}: {result}")

            if DEBUG_MODE:
                print(f"[DEBUG] [{reference_id}] Mengecek pembayaran Rp{amount}: {result}")
            
            if result['success'] and result['data']['status'] == 'PAID':
                if DEBUG_MODE:
                    print(f"[INFO] [{reference_id}] ✅ Pembayaran berhasil diterima.")
                return result['data']

            time.sleep(CHECK_INTERVAL)

        if DEBUG_MODE:
            print(f"[WARN] [{reference_id}] ⏱️ Timeout — belum ada pembayaran diterima.")
        return None

    except Exception as e:
        if DEBUG_MODE:
            print(f"[ERROR] [{reference_id}] ⚠️ Gagal monitoring pembayaran: {str(e)}")
        raise
