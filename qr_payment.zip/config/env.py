import os
import json
from dotenv import load_dotenv

load_dotenv()  # Memuat variabel dari file .env

# ─────────────────────────────────────────────
# 🔐 Fallback Loader
# ─────────────────────────────────────────────
def load_credentials(path='config/credentials.json'):
    try:
        with open(path, 'r') as file:
            return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

# ─────────────────────────────────────────────
# 🔧 Get Config Value
# ─────────────────────────────────────────────
def get_config_value(key, default=None):
    """
    Ambil nilai dari .env terlebih dahulu, lalu fallback ke credentials.json.
    """
    value = os.getenv(key)
    if value is not None:
        return value

    creds = load_credentials()
    return creds.get(key, default)

# ─────────────────────────────────────────────
# 📦 Shortcut
# ─────────────────────────────────────────────
AUTH_USERNAME = get_config_value('AUTH_USERNAME')
AUTH_TOKEN = get_config_value('AUTH_TOKEN')
BASE_QR_STRING = get_config_value('BASE_QR_STRING')
