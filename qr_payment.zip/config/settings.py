# Konfigurasi runtime
DEBUG_MODE = True

# Timeout dalam detik untuk monitoring pembayaran
CHECK_TIMEOUT = 600        # Default: 10 menit

# Interval antar cek (detik)
CHECK_INTERVAL = 3

# Path default untuk logo QR
DEFAULT_LOGO_PATH = 'static/logo.png'

# Path penyimpanan QR hasil generate
QR_SAVE_PATH = 'storage/qr/'

# Log file untuk debug & audit
LOG_FILE_PATH = 'storage/logs/payment.log'
