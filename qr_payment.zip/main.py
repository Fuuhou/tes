import sys
import requests
from core.generator import generate_qr
from core.validator import is_valid_qris_string
from core.checker import check_payment_status
from core.utils import format_rupiah, generate_tx_id
from config.env import get_config_value

# Load konfigurasi bot Telegram
BOT_TOKEN = get_config_value("BOT_TOKEN")
CHAT_ID = get_config_value("CHAT_ID")

def send_qr_to_telegram(image_path: str, caption: str):
    """
    Kirim gambar QR ke Telegram menggunakan requests.
    """
    if not BOT_TOKEN or not CHAT_ID:
        print("❌ BOT_TOKEN atau CHAT_ID belum diatur di .env / credentials.")
        return

    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendPhoto"
    try:
        with open(image_path, 'rb') as photo:
            response = requests.post(
                url,
                data={'chat_id': CHAT_ID, 'caption': caption},
                files={'photo': photo}
            )
        if response.status_code == 200:
            print("✅ QR berhasil dikirim ke Telegram.")
        else:
            print(f"❌ Gagal kirim ke Telegram: {response.text}")
    except Exception as e:
        print(f"❌ Error saat kirim ke Telegram: {str(e)}")

def main():
    try:
        # Input nominal dari CLI atau prompt manual
        if len(sys.argv) > 1:
            try:
                amount = int(sys.argv[1])
            except ValueError:
                print("❌ Nominal harus berupa angka bulat.")
                return
        else:
            amount_str = input("Masukkan nominal pembayaran (contoh: 10000): ")
            try:
                amount = int(amount_str)
            except ValueError:
                print("❌ Input tidak valid, hanya boleh angka.")
                return

        tx_id = generate_tx_id()

        # 1. Generate QR
        qr_result = generate_qr(amount, save_as=f"qr_{amount}_{tx_id}.png")
        qr_string = qr_result['qr_string']
        qr_path = qr_result['qr_image_path']

        print(f"[INFO] QRIS {format_rupiah(amount)} berhasil dibuat:")
        print(f"  ⤷ Path gambar: {qr_path}")
        print(f"  ⤷ QR string: {qr_string}")
        print(f"  ⤷ ID Transaksi: {tx_id}")

        # 2. Validasi
        if is_valid_qris_string(qr_string):
            print("[VALIDATOR] ✅ QR string lolos validasi format & CRC16")
        else:
            print("[VALIDATOR] ❌ QR string tidak valid!")
            return

        # 3. Kirim ke Telegram
        caption = (
            f"📦 QR untuk {format_rupiah(amount)}\n"
            f"🆔 ID Transaksi: `{tx_id}`\n"
            f"⏳ Bot sedang memantau status pembayaran..."
        )
        send_qr_to_telegram(qr_path, caption)

        # 4. Monitor status
        print(f"[MONITOR] 🔄 Memantau status pembayaran {format_rupiah(amount)}...")
        status = check_payment_status(reference_id=tx_id, amount=amount)

        if status:
            print("[STATUS] 🎉 Pembayaran berhasil diterima!")
            print("  ⤷ Detail transaksi:")
            for k, v in status.items():
                print(f"    - {k}: {v}")
        else:
            print("[STATUS] ⚠️ Pembayaran tidak diterima (timeout atau gagal)")

    except Exception as e:
        print(f"[ERROR] 🚫 Terjadi kesalahan: {str(e)}")

if __name__ == "__main__":
    main()
